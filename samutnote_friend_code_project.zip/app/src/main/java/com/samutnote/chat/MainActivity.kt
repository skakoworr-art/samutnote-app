package com.samutnote.chat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.InputType
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : Activity() {
    private val brown = Color.rgb(101, 67, 54)
    private val cream = Color.rgb(250, 246, 239)
    private val pale = Color.rgb(239, 228, 215)
    private var auth: FirebaseAuth? = null
    private var db: FirebaseDatabase? = null
    private var activeFriendId: String? = null
    private var activeFriendName = ""
    private var activeChatId: String? = null
    private var messageListener: ChildEventListener? = null
    private var friendsListener: ValueEventListener? = null
    private lateinit var status: TextView
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cream
        window.navigationBarColor = cream
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        try {
            FirebaseApp.initializeApp(this)
            auth = FirebaseAuth.getInstance()
            db = FirebaseDatabase.getInstance()
        } catch (_: Exception) { }
        showAuthScreen()
    }

    private fun makeBase(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cream)
        setPadding(20, 16, 20, 14)
    }
    private fun txt(s: String, size: Float = 16f, color: Int = brown) =
        TextView(this).apply { text = s; textSize = size; setTextColor(color) }
    private fun bg(color: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = 18f
    }
    private fun field(h: String, password: Boolean = false): EditText = EditText(this).apply {
        hint = h; textSize = 16f; setSingleLine(true); setTextColor(brown)
        setPadding(14, 7, 14, 7); background = bg(pale)
        if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    private fun btn(s: String, action: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(Color.WHITE); background = bg(brown)
        setOnClickListener { action() }
    }
    private fun setRoot(v: View) { setContentView(v) }
    private fun ready(): Boolean {
        if (FirebaseApp.getApps(this).isEmpty() || auth == null || db == null) {
            status.text = "ยังไม่ได้ตั้งค่า Firebase กรุณาทำตาม README ก่อนใช้งานออนไลน์"
            return false
        }
        return true
    }
    private fun showAuthScreen() {
        val box = makeBase()
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.addView(txt("📒", 64f).apply { gravity = Gravity.CENTER; setPadding(0, 8, 0, 0) })
        box.addView(txt("สมุดโน๊ต", 30f).apply { typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        box.addView(txt("แชทส่วนตัวกับเพื่อน", 15f).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) })
        status = txt("สมัครบัญชีหรือเข้าสู่ระบบเพื่อเริ่มต้น", 13f)
        box.addView(status)
        val email = field("อีเมล")
        val password = field("รหัสผ่าน (อย่างน้อย 6 ตัว)", true)
        val nickname = field("ชื่อที่แสดง")
        box.addView(email); box.addView(password); box.addView(nickname)
        box.addView(btn("สมัครบัญชี") {
            if (!ready()) return@btn
            val e = email.text.toString().trim(); val p = password.text.toString()
            if (e.isBlank() || p.length < 6) { status.text = "กรอกอีเมลและรหัสผ่านอย่างน้อย 6 ตัว"; return@btn }
            auth!!.createUserWithEmailAndPassword(e, p).addOnSuccessListener { result ->
                val user = result.user ?: return@addOnSuccessListener
                val uid = user.uid
                val code = "SN" + uid.replace(Regex("[^A-Za-z0-9]"), "").takeLast(7).uppercase()
                val profile = mapOf("nickname" to nickname.text.toString().trim().ifBlank { "เพื่อน" }, "friendCode" to code)
                val updates = mapOf<String, Any>(
                    "profiles/$uid" to profile,
                    "publicProfiles/$uid" to profile
                )
                db!!.reference.updateChildren(updates).addOnSuccessListener {
                    status.text = "สมัครสำเร็จ! รหัสเพื่อนของคุณคือ $code"
                    showHomeScreen()
                }.addOnFailureListener { status.text = "บันทึกโปรไฟล์ไม่สำเร็จ: ${it.localizedMessage}" }
            }.addOnFailureListener { status.text = "สมัครไม่สำเร็จ: ${it.localizedMessage}" }
        })
        box.addView(btn("เข้าสู่ระบบ") {
            if (!ready()) return@btn
            auth!!.signInWithEmailAndPassword(email.text.toString().trim(), password.text.toString())
                .addOnSuccessListener { showHomeScreen() }
                .addOnFailureListener { status.text = "เข้าสู่ระบบไม่สำเร็จ: ${it.localizedMessage}" }
        })
        box.addView(txt("หมายเหตุ: ต้องตั้งค่า Firebase ก่อนจึงจะสมัครและแชทออนไลน์ได้", 12f).apply { setPadding(0, 12, 0, 0) })
        setRoot(ScrollView(this).apply { addView(box) })
        if (auth?.currentUser != null && db != null) showHomeScreen()
    }

    private fun showHomeScreen() {
        val user = auth?.currentUser ?: return showAuthScreen()
        val box = makeBase()
        val heading = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        heading.addView(txt("📒 สมุดโน๊ต", 24f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(btn("ออก") { auth?.signOut(); removeFriendsListener(); showAuthScreen() })
        box.addView(heading)
        status = txt("รหัสเพื่อนของคุณ: กำลังโหลด…", 14f)
        box.addView(status)
        db!!.reference.child("profiles").child(user.uid).child("friendCode").get().addOnSuccessListener {
            status.text = "รหัสเพื่อนของคุณ: ${it.getValue(String::class.java) ?: "ยังไม่มี"}"
        }
        box.addView(txt("เพิ่มเพื่อนด้วยรหัส", 17f).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, 16, 0, 4) })
        val codeField = field("กรอกรหัสเพื่อน เช่น SN1234567")
        box.addView(codeField)
        box.addView(btn("ค้นหาและเพิ่มเพื่อน") { addFriend(codeField.text.toString().trim().uppercase()) })
        box.addView(txt("เพื่อนของฉัน", 18f).apply { typeface = Typeface.DEFAULT_BOLD; setPadding(0, 18, 0, 8) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list)
        setRoot(ScrollView(this).apply { addView(box) })
        removeFriendsListener()
        val ref = db!!.reference.child("profiles").child(user.uid).child("friends")
        friendsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                list.removeAllViews()
                if (!snapshot.exists()) list.addView(txt("ยังไม่มีเพื่อน เพิ่มเพื่อนด้วยรหัสด้านบนได้เลย", 14f))
                for (item in snapshot.children) {
                    val friendId = item.key ?: continue
                    db!!.reference.child("profiles").child(friendId).get().addOnSuccessListener { profile ->
                        val name = profile.child("nickname").getValue(String::class.java) ?: "เพื่อน"
                        val code = profile.child("friendCode").getValue(String::class.java) ?: ""
                        list.addView(btn("$name  ·  $code  ·  เปิดแชท") { openChat(friendId, name) })
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) { status.text = "โหลดเพื่อนไม่ได้: ${error.message}" }
        }
        ref.addValueEventListener(friendsListener!!)
    }

    private fun removeFriendsListener() {
        val uid = auth?.currentUser?.uid
        if (uid != null && friendsListener != null) {
            db?.reference?.child("profiles")?.child(uid)?.child("friends")?.removeEventListener(friendsListener!!)
        }
        friendsListener = null
    }

    private fun addFriend(code: String) {
        if (code.isBlank()) { status.text = "กรอกรหัสเพื่อนก่อน"; return }
        val user = auth?.currentUser ?: return
        db!!.reference.child("publicProfiles").orderByChild("friendCode").equalTo(code).limitToFirst(1).get()
            .addOnSuccessListener { found ->
                val target = found.children.firstOrNull()
                if (target == null) { status.text = "ไม่พบรหัสนี้ ตรวจสอบรหัสอีกครั้ง"; return@addOnSuccessListener }
                val friendId = target.key ?: return@addOnSuccessListener
                if (friendId == user.uid) { status.text = "เพิ่มตัวเองเป็นเพื่อนไม่ได้"; return@addOnSuccessListener }
                val myProfile = db!!.reference.child("profiles").child(user.uid)
                myProfile.get().addOnSuccessListener { mine ->
                    val myName = mine.child("nickname").getValue(String::class.java) ?: "เพื่อน"
                    val myCode = mine.child("friendCode").getValue(String::class.java) ?: ""
                    val theirName = target.child("nickname").getValue(String::class.java) ?: "เพื่อน"
                    val theirCode = target.child("friendCode").getValue(String::class.java) ?: ""
                    val chatId = listOf(user.uid, friendId).sorted().joinToString("_")
                    val all = hashMapOf<String, Any>(
                        "profiles/${user.uid}/friends/$friendId" to true,
                        "profiles/$friendId/friends/${user.uid}" to true,
                        "publicProfiles/${user.uid}" to mapOf("nickname" to myName, "friendCode" to myCode),
                        "rooms/$chatId/members/${user.uid}" to true,
                        "rooms/$chatId/members/$friendId" to true
                    )
                    db!!.reference.updateChildren(all).addOnSuccessListener {
                        status.text = "เพิ่ม $theirName สำเร็จ"
                    }.addOnFailureListener { status.text = "เพิ่มเพื่อนไม่สำเร็จ: ${it.localizedMessage}" }
                }.addOnFailureListener { status.text = "อ่านโปรไฟล์ของคุณไม่สำเร็จ: ${it.localizedMessage}" }
            }.addOnFailureListener { status.text = "ค้นหาไม่สำเร็จ: ${it.localizedMessage}" }
    }

    private fun openChat(friendId: String, name: String) {
        activeFriendId = friendId
        activeFriendName = name
        val userId = auth?.currentUser?.uid ?: return
        activeChatId = listOf(userId, friendId).sorted().joinToString("_")
        showChatScreen()
    }

    private fun showChatScreen() {
        val user = auth?.currentUser ?: return
        val chatId = activeChatId ?: return
        val box = makeBase()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(txt("‹  $activeFriendName", 22f).apply { typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(btn("กลับ") { showHomeScreen() })
        box.addView(top)
        val conversation = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 10, 0, 10) }
        val scroll = ScrollView(this)
        scroll.addView(conversation)
        box.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val composer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val message = field("พิมพ์ข้อความ…")
        val send = btn("ส่ง") {
            val body = message.text.toString().trim()
            if (body.isNotEmpty()) {
                val profileRef = db!!.reference.child("profiles").child(user.uid)
                profileRef.child("nickname").get().addOnSuccessListener { n ->
                    val payload = mapOf("uid" to user.uid, "nickname" to (n.getValue(String::class.java) ?: "เพื่อน"),
                        "text" to body, "createdAt" to ServerValue.TIMESTAMP)
                    db!!.reference.child("rooms").child(chatId).child("messages").push().setValue(payload)
                        .addOnSuccessListener {
                            message.setText("")
                            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                                .hideSoftInputFromWindow(message.windowToken, 0)
                        }.addOnFailureListener { Toast.makeText(this, "ส่งไม่สำเร็จ: ${it.localizedMessage}", Toast.LENGTH_LONG).show() }
                }
            }
        }
        composer.addView(message, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(send)
        box.addView(composer)
        setRoot(box)
        val ref = db!!.reference.child("rooms").child(chatId).child("messages").limitToLast(250)
        messageListener?.let { ref.removeEventListener(it) }
        messageListener = object : ChildEventListener {
            override fun onChildAdded(s: DataSnapshot, previousChildName: String?) {
                val sender = s.child("nickname").getValue(String::class.java) ?: "เพื่อน"
                val body = s.child("text").getValue(String::class.java) ?: return
                val mine = s.child("uid").getValue(String::class.java) == user.uid
                val bubble = TextView(this@MainActivity).apply {
                    text = "$sender\n$body"; textSize = 15f; setTextColor(brown); setPadding(13, 9, 13, 9)
                    background = bg(if (mine) pale else Color.WHITE)
                }
                val row = LinearLayout(this@MainActivity).apply {
                    gravity = if (mine) Gravity.END else Gravity.START
                    setPadding(0, 4, 0, 4)
                    addView(bubble, LinearLayout.LayoutParams(-2, -2).apply {
                        width = (resources.displayMetrics.widthPixels * .70).toInt()
                    })
                }
                conversation.addView(row)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
            override fun onCancelled(error: DatabaseError) { Toast.makeText(this@MainActivity, "โหลดข้อความไม่ได้: ${error.message}", Toast.LENGTH_LONG).show() }
            override fun onChildChanged(s: DataSnapshot, previousChildName: String?) {}
            override fun onChildRemoved(s: DataSnapshot) {}
            override fun onChildMoved(s: DataSnapshot, previousChildName: String?) {}
        }
        ref.addChildEventListener(messageListener!!)
    }

    override fun onDestroy() {
        super.onDestroy()
        removeFriendsListener()
        messageListener?.let { l ->
            val id = activeChatId
            if (id != null) db?.reference?.child("rooms")?.child(id)?.child("messages")?.removeEventListener(l)
        }
    }
}
